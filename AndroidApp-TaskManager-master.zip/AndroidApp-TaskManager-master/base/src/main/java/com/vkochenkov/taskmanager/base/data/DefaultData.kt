package com.vkochenkov.taskmanager.base.data

object DefaultData {

    const val COMMON_DELIMITER = "-_~"

    val defaultStatuses = listOf("To do", "In progress", "Review", "Done")
}